
//! Project version number for CTNotificationService.
extern double CTNotificationServiceVersionNumber;

//! Project version string for CTNotificationService.
extern const unsigned char CTNotificationServiceVersionString[];

#import "CTNotificationServiceExtension.h"
