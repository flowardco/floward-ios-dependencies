//
//  PhoneNumberKit.h
//  PhoneNumberKit
//
//  Created by Roy Marmelstein on 26/09/2015.
//  Copyright © 2021 Roy Marmelstein. All rights reserved.
//

@import Foundation;

//! Project version number for PhoneNumberKit.
FOUNDATION_EXPORT double PhoneNumberKitVersionNumber;

//! Project version string for PhoneNumberKit.
FOUNDATION_EXPORT const unsigned char PhoneNumberKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PhoneNumberKit/PublicHeader.h>


