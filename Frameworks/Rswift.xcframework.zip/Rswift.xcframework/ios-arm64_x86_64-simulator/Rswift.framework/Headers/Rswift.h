//
//  Rswift.h
//  Rswift
//
//  Created by Mathijs Kadijk on 04-12-15.
//  From: https://github.com/mac-cain13/R.swift.Library
//  License: MIT License
//

#import <UIKit/UIKit.h>

//! Project version number for Rswift.
FOUNDATION_EXPORT double RswiftVersionNumber;

//! Project version string for Rswift.
FOUNDATION_EXPORT const unsigned char RswiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Rswift/PublicHeader.h>
