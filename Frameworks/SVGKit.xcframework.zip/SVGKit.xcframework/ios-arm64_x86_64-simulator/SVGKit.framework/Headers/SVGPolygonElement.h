//
//  SVGPolygonElement.h
//  SVGKit
//
//  Copyright Matt Rajca 2011. All rights reserved.
//

#import "BaseClassForAllSVGBasicShapes.h"
#import "BaseClassForAllSVGBasicShapes_ForSubclasses.h"

@interface SVGPolygonElement : BaseClassForAllSVGBasicShapes { }

@end
