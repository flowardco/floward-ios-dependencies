//
//  SwiftyCam-iOS.h
//  SwiftyCam-iOS
//
//  Created by Jon Andersen on 3/20/17.
//  Copyright © 2017 Cappsule. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftyCam-iOS.
FOUNDATION_EXPORT double SwiftyCam_iOSVersionNumber;

//! Project version string for SwiftyCam-iOS.
FOUNDATION_EXPORT const unsigned char SwiftyCam_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftyCam_iOS/PublicHeader.h>


